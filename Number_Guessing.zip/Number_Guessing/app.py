from flask import Flask, render_template, request
import random

app = Flask(__name__)

# Random number between 1 and 100
number_to_guess = random.randint(1, 100)

@app.route("/", methods=["GET", "POST"])
def index():
    global number_to_guess
    message = ""
    guess = None
    if request.method == "POST":
        guess = int(request.form["guess"])
        if guess < number_to_guess:
            message = "Too low! Try a higher number."
        elif guess > number_to_guess:
            message = "Too high! Try a lower number."
        else:
            message = f"🎉 Congratulations! You guessed it right. The number was {number_to_guess}."
            number_to_guess = random.randint(1, 100)  # Reset the game
    return render_template("index.html", message=message, guess=guess)

if __name__ == "__main__":
    app.run(debug=True)
